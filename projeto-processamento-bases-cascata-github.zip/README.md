# Projeto de Processamento de Bases por Competência

Projeto em Python para processamento de bases mensais, desenvolvido com abordagem **Cascata (Waterfall)**.

## Objetivo

O processo recebe uma base da competência atual, enriquece seus registros utilizando uma base de referência e compara cada registro com competências anteriores para identificar repetições.

### Fluxo

`Base Atual → Validação → Composição do Campo → Comparação Histórica → Classificação → Saídas`

## Funcionalidades

- Validação das colunas obrigatórias;
- Normalização de dados;
- Composição de campo a partir de base de referência;
- Comparação com histórico;
- Identificação de registros repetidos em competências anteriores;
- Classificação em `NOVO` e `REPETIDO`;
- Geração de base tratada;
- Geração de relatório de registros repetidos;
- Geração de resumo estatístico;
- Testes automatizados com pytest.

## Estrutura

```text
projeto-processamento-bases-cascata/
├── README.md
├── requirements.txt
├── .gitignore
├── src/
│   ├── main.py
│   ├── processor.py
│   └── config.py
├── tests/
│   └── test_processor.py
├── docs/
│   ├── FLUXO.md
│   └── MODELO_CASCATA.md
└── data/
    ├── input/
    ├── reference/
    ├── history/
    └── output/
```

## Instalação

```bash
python -m venv .venv
```

Windows:

```bash
.venv\Scripts\activate
```

Linux/macOS:

```bash
source .venv/bin/activate
```

Depois:

```bash
pip install -r requirements.txt
```

## Execução

```bash
python src/main.py --input data/input/base_atual.csv --reference data/reference/base_referencia.csv --history data/history/historico.csv --output data/output
```

## Entradas

### Base atual

Deve possuir, no mínimo:

- `cpf`
- `cnes`
- `competencia`
- `codigo`

### Base de referência

Deve possuir:

- `codigo`
- `descricao`

A coluna `descricao` será utilizada para compor o campo `campo_composto`.

### Base histórica

Deve possuir:

- `cpf`
- `cnes`
- `competencia`

## Regra de repetição

A chave padrão para comparação histórica é:

`cpf + cnes`

A competência não integra a chave de repetição. Ela é preservada para indicar em qual competência o registro foi encontrado.

As regras podem ser alteradas em `src/config.py`.

## Saídas

O sistema gera:

- `base_tratada.csv`
- `registros_repetidos.csv`
- `resumo_processamento.json`

## Testes

Execute:

```bash
pytest -q
```

## Segurança e LGPD

Este repositório contém apenas estrutura e código. **Não publique dados pessoais ou dados sensíveis reais no GitHub.**

Os diretórios `data/` estão configurados no `.gitignore` para evitar o versionamento das bases.

## Modelo Cascata

O projeto está organizado em seis fases:

1. Requisitos
2. Modelagem
3. Implementação
4. Testes
5. Implantação
6. Manutenção

Detalhamento em `docs/MODELO_CASCATA.md`.
