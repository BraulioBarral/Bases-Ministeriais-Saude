# Modelo Cascata

O projeto segue o modelo **Cascata (Waterfall)**, com etapas sequenciais e critérios de validação antes da passagem para a etapa seguinte.

## 1. Requisitos

Definição de:

- bases de entrada;
- campos obrigatórios;
- chave de comparação;
- regras de composição;
- regras de duplicidade;
- produtos de saída.

## 2. Modelagem

Definição da estrutura das bases e do fluxo de transformação.

## 3. Implementação

Desenvolvimento do processamento em Python/Pandas.

## 4. Testes

Validação das regras e dos resultados esperados.

## 5. Implantação

Execução do processamento em ambiente definido e geração dos produtos.

## 6. Manutenção

Correções, ajustes de regras e evolução controlada do processo.
