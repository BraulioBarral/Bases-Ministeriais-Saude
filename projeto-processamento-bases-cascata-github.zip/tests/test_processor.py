import pandas as pd

from src.processor import compose_field, compare_history


def test_compose_field():
    current = pd.DataFrame(
        {
            "cpf": ["1"],
            "cnes": ["10"],
            "competencia": ["2026-08"],
            "codigo": ["A"],
        }
    )

    reference = pd.DataFrame(
        {
            "codigo": ["A"],
            "descricao": ["Exemplo"],
        }
    )

    result = compose_field(current, reference)

    assert result.loc[0, "campo_composto"] == "Exemplo"


def test_compare_history():
    current = pd.DataFrame(
        {
            "cpf": ["1", "2"],
            "cnes": ["10", "20"],
            "competencia": ["2026-08", "2026-08"],
        }
    )

    history = pd.DataFrame(
        {
            "cpf": ["1"],
            "cnes": ["10"],
            "competencia": ["2026-07"],
        }
    )

    result, repeated = compare_history(
        current,
        history,
    )

    assert result.loc[0, "situacao"] == "REPETIDO"
    assert result.loc[1, "situacao"] == "NOVO"
    assert len(repeated) == 1
