from pathlib import Path
import json
import pandas as pd

from config import (
    REQUIRED_COLUMNS,
    KEY_COLUMNS,
    REFERENCE_KEY,
    REFERENCE_VALUE,
    OUTPUT_COMPOSED_FIELD,
)


def read_csv(path: str) -> pd.DataFrame:
    return pd.read_csv(path, dtype=str).fillna("")


def normalize(df: pd.DataFrame) -> pd.DataFrame:
    result = df.copy()
    for col in result.columns:
        result[col] = result[col].astype(str).str.strip()
    return result


def validate_columns(df: pd.DataFrame, required: list[str]) -> None:
    missing = [column for column in required if column not in df.columns]
    if missing:
        raise ValueError(
            "Colunas obrigatórias ausentes: " + ", ".join(missing)
        )


def compose_field(
    current: pd.DataFrame,
    reference: pd.DataFrame,
) -> pd.DataFrame:
    validate_columns(reference, [REFERENCE_KEY, REFERENCE_VALUE])

    ref = (
        reference[[REFERENCE_KEY, REFERENCE_VALUE]]
        .drop_duplicates(subset=[REFERENCE_KEY])
        .rename(columns={REFERENCE_VALUE: OUTPUT_COMPOSED_FIELD})
    )

    return current.merge(
        ref,
        how="left",
        on=REFERENCE_KEY,
    )


def compare_history(
    current: pd.DataFrame,
    history: pd.DataFrame,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    validate_columns(current, KEY_COLUMNS + ["competencia"])
    validate_columns(history, KEY_COLUMNS + ["competencia"])

    historical_keys = history[KEY_COLUMNS].drop_duplicates().copy()
    historical_keys["_ja_existia"] = True

    result = current.merge(
        historical_keys,
        on=KEY_COLUMNS,
        how="left",
    )

    result["situacao"] = (
        result["_ja_existia"]
        .map({True: "REPETIDO", False: "NOVO"})
        .fillna("NOVO")
    )

    result = result.drop(columns=["_ja_existia"])

    repeated = result[result["situacao"] == "REPETIDO"].copy()

    return result, repeated


def process(
    input_path: str,
    reference_path: str,
    history_path: str,
    output_dir: str,
) -> dict:
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)

    current = normalize(read_csv(input_path))
    reference = normalize(read_csv(reference_path))
    history = normalize(read_csv(history_path))

    validate_columns(current, REQUIRED_COLUMNS)
    validate_columns(history, REQUIRED_COLUMNS)

    enriched = compose_field(current, reference)

    treated, repeated = compare_history(
        enriched,
        history,
    )

    treated.to_csv(
        output / "base_tratada.csv",
        index=False,
    )

    repeated.to_csv(
        output / "registros_repetidos.csv",
        index=False,
    )

    summary = {
        "total_registros": int(len(treated)),
        "registros_novos": int(
            (treated["situacao"] == "NOVO").sum()
        ),
        "registros_repetidos": int(
            (treated["situacao"] == "REPETIDO").sum()
        ),
        "competencias_processadas": sorted(
            treated["competencia"]
            .dropna()
            .unique()
            .tolist()
        ),
    }

    (output / "resumo_processamento.json").write_text(
        json.dumps(
            summary,
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )

    return summary
