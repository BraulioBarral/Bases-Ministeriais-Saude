# Configurações do processamento

REQUIRED_COLUMNS = ["cpf", "cnes", "competencia", "codigo"]

KEY_COLUMNS = ["cpf", "cnes"]

REFERENCE_KEY = "codigo"
REFERENCE_VALUE = "descricao"

OUTPUT_COMPOSED_FIELD = "campo_composto"
