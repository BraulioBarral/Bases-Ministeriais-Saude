import argparse

from processor import process


def main():
    parser = argparse.ArgumentParser(
        description="Processamento de bases por competência"
    )

    parser.add_argument(
        "--input",
        required=True,
        help="Base da competência atual",
    )

    parser.add_argument(
        "--reference",
        required=True,
        help="Base de referência",
    )

    parser.add_argument(
        "--history",
        required=True,
        help="Base histórica",
    )

    parser.add_argument(
        "--output",
        default="data/output",
        help="Diretório de saída",
    )

    args = parser.parse_args()

    summary = process(
        args.input,
        args.reference,
        args.history,
        args.output,
    )

    print("Processamento concluído.")

    for key, value in summary.items():
        print(f"{key}: {value}")


if __name__ == "__main__":
    main()
